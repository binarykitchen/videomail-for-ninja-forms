<a href="<?php echo $value['url']; ?>">View Online</a>
